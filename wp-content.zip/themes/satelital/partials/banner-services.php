<!-- Incluir Seccion banner de servicios -->
<section class="sectionCommonBanner__services">
	<div class="container">
		<!-- Texto -->
		<p class="text-uppercase"><?php _e( 'consulte acerca de nuestros servicios' , LANG ); ?></p>
		<!-- Boton ver más -->
		<a href="#" class="btn__show-more text-uppercase"><?php _e( 'click aquí' , LANG ); ?></a>
	</div><!-- /.container -->
</section><!-- /.sectionCommonBanner__services -->