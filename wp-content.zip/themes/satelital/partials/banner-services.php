
<!-- Banner Soluciones -->
<section class="pageCommon__banner-services relative text-xs-center">
	<div class="container">
		<div class="container-flex align-content">

			<!-- Imagen Ocultar en mobile --> <figure class="hidden-xs-down"><img src="<?= IMAGES ?>/auto_rojo_service_satelital_lima.png" alt="auto_rojo_service_satelital_lima" class="img-fluid"></figure>

			<!-- Texto --> <h2><?php _e('Soluciones las 24 Horas' , LANG ); ?></h2>
			<!-- Botón --> <a href="" class="pageCommun__btn-read-more"><?php _e('click aquí' , LANG ); ?></a>
		</div> <!-- /.container-flex align-content -->
	</div> <!-- /.container -->
</section> <!-- /.pageCommon__banner-services -->