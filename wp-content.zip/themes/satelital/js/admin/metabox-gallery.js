var j = jQuery.noConflict();

/* 
* Array Unique: eliminar valores duplicados de un array en Javascript
*/


/* Funcion del documento */
(function($){

    j('#add_image_btn').on('click',function(e) {

        e.preventDefault();

        var post_data = j(this).attr('data-id-post');
        
        frame = wp.media({
            title   : 'Agrega tu título aquí',
            frame   : 'post',
            multiple: true, // set to false if you want only one image
            library : { type : 'image'},
            button  : { text : 'Agregar Imagen' },
        });

        frame.on('close',function(data) {

            var input_data = j("#imageurls_"+post_data);
            
            var imageArray = input_data.val().split(",");

            images = frame.state().get('selection');
            
            images.each(function(image) {
                //imageArray.push(image.attributes.url); // want other attributes? Check the available ones with console.log(image.attributes);
                imageArray.push(image.attributes.id); // want other attributes? Check the available ones with console.log(image.attributes);
            });
 
            j("#imageurls_"+post_data).val(imageArray.join(",")); // Adds all image URL's comma seperated to a text input
        });
        
        frame.open();
    });


    //Actualizar imagen
    j(".js-update-image").on('click',function(e){
        e.preventDefault(); //arreglar la customizacion

        var this_link = j(this);

        var frame; 
        //id de post
        var data_id_post = this_link.attr('data-id-post');
        //id image
        var data_image   = this_link.attr('data-id-img'); //console.log( data_image );

        // If the media frame already exists, reopen it.
        if ( frame ) { frame.open(); return; }

        // Create a new media frame
        frame = wp.media({
            title   : 'Agrega tu imagen aquí',
            multiple:  false, // set to false if you want only one image
            button  : { text : 'Usa esta Imagen' },
        });

        //al abrir el frame
        frame.on('open', function(){
            var selection = frame.state().get('selection');
            var selected  = data_image; // the id of the image
            if (selected) { selection.add(wp.media.attachment(selected)); }
        });
        //al cerrar el frame
        frame.on('select', function() {
            attachment =  frame.state().get('selection').first().toJSON(); //console.log(attachment );

            //valor de id de imagen actual cambiada o seleccionada
            var current_id_img = attachment.id;
            //actualizar valor de la imagen en el atributo data img
            this_link.attr( 'data-id-img', current_id_img );

            //actualizar nuevos valores en el input oculto de actual post
            var array_valores = j("#imageurls_"+data_id_post).val();
            //buscar id actual eliminarlo y reemplazarlo por la seleccion
            array_valores = array_valores.replace( data_image ,  current_id_img );
            //actualizar
            j("#imageurls_"+data_id_post).val( array_valores ); 


            //mostrar imagen temporal
            this_link.html("");
            this_link.append("<img src="+attachment.url+" alt="+attachment.name+" class='' style='max-width: 100%; width: 100%; height: 100%; margin: 0 auto;' />");
        });



        frame.open(); 

    });

    //Eliminar una imagen
    j(".js-delete-image").on('click',function(e){
        e.preventDefault();

        //id de post
        var data_id_post = j(this).attr('data-id-post');

        //id de imagen 
        var data_id_img  = j(this).attr('data-id-img');
        //console.log(data_id_img);

        //ocultar imagen display none
        j(this).parent('figure').css('display','none');

        var input_data = j("#imageurls_"+data_id_post);
        //var imageArray = input_data.val().split(",");
        var valores_array = input_data.val();

        //buscar y eliminar elemento id de imagen  del arreglo
        valores_array = valores_array.replace( data_id_img , '-1' );
        input_data.val( valores_array );
        /*var i = imageArray.indexOf(data_id_img);
        if(i != -1 ) { 
            imageArray.splice( i , 1); 

            if( imageArray.length == 0 ){
               input_data.val('-1');
            }else{
                input_data.val(imageArray.join(","));
            }
        }*/

        //console.log(imageArray);

    });

})(jQuery)







